##Part 1
setwd("C:\\Users\\ASUS\\Desktop\\Week 5 Lab 5")
data<-read.table("Data.txt",header=TRUE,sep=",")
fix(data)
attach(data)

##Part 1
names(data)<-c("X1","X2")
attach(data)

hist(X2,main="Histogram for Number of Shareholders")

##Part 2
hist(X2,main="Histogram for Number of Shareholders", breaks=seq(13,270,length=8),right=FALSE)
histogram<-hist(X2,main="Histogram for Number of Shareholders", breaks=seq(13,270,length=8),right=FALSE)


##Part 3
breaks <- round(histogram$breaks)
breaks

freq <-histogram$counts
freq

mids<-histogram$mids
mids

classes <- c()

for (i in 1:length(breaks)-1) {
  classes[i]<-paste0("[",breaks[i],",",breaks[i+1],")")
}
classes
cbind(Classes = classes,Frequency = freq)


##Part 4
lines(mids,freq)
plot(mids,freq,type = 'l',main = "Frequency polygon for shareholders",xlab = "shareholders",ylab = "Frequency",ylim = c(0,max(freq)))

##Part 5
cum.freq<-cumsum(freq)

new<-c()

for (i in 1:length(breaks)) {
  if(i==1){
    new[i]=0
  }else{
    new[i]=cum.freq[i-1]
  }
}

plot(breaks, new,type = 'l',main = "Cumalative Frequency Polygon for Shareholders",
     xlab = "Shareholder",ylab="Cumulative Frequency",ylim = c(0,max(cum.freq)))
cbind(Upper = breaks, CumFreq = new)
  
##Exercise
##Q1
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)
Delivery_Times

names(Delivery_Times)

names(Delivery_Times) <- c("Time")


##Q2
hist(Delivery_Times$Time,main = "Histogram for Delivery Times",xlab = "Delivery Time (minutes)",col = "lightblue",breaks = seq(20, 70, length=10),right = FALSE)

histogram2 <- hist(Delivery_Times$Time,breaks = seq(20, 70, length=10),right = FALSE,main = "Histogram for Delivery Times",xlab = "Delivery Time (minutes)",col = "lightgreen")


## Q3
breaks <- round(histogram2$breaks)
freq <- histogram2$counts
mids <- histogram2$mids


classes <- c()
for (i in 1:(length(breaks)-1)) {
  classes[i] <- paste0("[", breaks[i], ",", breaks[i+1], ")")
}

freq_table <- cbind(Classes = classes, Frequency = freq)
freq_table


## Q4
cum.freq <- cumsum(freq)


new <- c()
for (i in 1:length(breaks)) {
  if (i == 1) {
    new[i] = 0
  } else {
    new[i] = cum.freq[i-1]
  }
}

plot(breaks, new, type = 'l',main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)",ylab = "Cumulative Frequency",
     ylim = c(0, max(cum.freq)),col = "red", lwd = 2)



cbind(Upper = breaks, CumFreq = new)

